import Welcome from "./components/Welcome"
import 'antd/dist/reset.css';
import { createBrowserHistory } from 'history';
export const history = createBrowserHistory();
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Login from "./components/authen/Login";
import SignUp from "./components/authen/SignUp";
import DashBoard from "./components/DashBoard";
import { AuthenticationMiddle } from "./middleware/authentication";
import Authorize from "./middleware/authorize";
export default function App() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="/signup" element={<SignUp />} />
                <Route path="*" element={<DashBoard />} />
                <Route element={<AuthenticationMiddle />}>
                    <Route path="/" element={<Welcome />} />
                    <Route path="/dashboard" element={
                        <DashBoard />
                    } />
                </Route>
            </Routes>
        </BrowserRouter>
    );
}