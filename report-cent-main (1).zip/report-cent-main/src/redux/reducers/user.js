import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import { message } from 'antd';
const initialState = {
    data: {},
    role: null
}

export const UserSlice = createSlice({
    name: 'user',
    initialState,
    reducers: {
        getUser: (state, action) => {
            console.log("aaaaa")
        },
    },
    extraReducers: builder => {
    }
})
export const { getUser } = UserSlice.actions



export default UserSlice.reducer


