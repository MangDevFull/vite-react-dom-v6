export default function SignUp(){
    return (
        <>
            this is signup
        </>
    )
}