export default{
    HOME_PAGE : "/",
    LOGIN_PAGE : "/login",
    ACCOUNTANT_PAGE: "/accountant",
    MARKETING_PAGE:"/marketing",
    SALE_PAGE:"/sale"
}