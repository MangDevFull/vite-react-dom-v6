export default function DashBoard() {
    return (
        <>
            <div className="wrapper">
                <h1>Welcome haha</h1>
            </div>
        </>
    );
}