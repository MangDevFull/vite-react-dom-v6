import React from 'react';
import { Outlet , Navigate } from 'react-router-dom';
console.log(" localStorage.getItem('user')", localStorage.getItem('user'))
export const ProtectedRoute = () => {
    const token  = localStorage.getItem('token')
    if (!token) {
        return (
          <Navigate
            to={{ pathname: "/login", state: { from: location } }}
            replace
          />
        );
      }
      return <Outlet />;
};