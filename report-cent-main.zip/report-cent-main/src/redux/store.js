import { configureStore } from '@reduxjs/toolkit'
import UserSlice from "./reducers/user"

const store = configureStore({
    reducer: {
        vouchers: UserSlice,
    },
})
export default store
