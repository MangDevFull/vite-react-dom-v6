import { useState, useEffect } from "react"
import "./style.css"
import axiosService from "../../utils/axios.config";
import { message } from "antd";
import { useNavigate } from "react-router-dom";
export default function Login() {
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")
    let navigate = useNavigate();

    const onChangeEmail = (e) => {
        setEmail(e.target.value)
    }
    const onChangePassword = (e) => {
        setPassword(e.target.value)
    }
    useEffect(() => {
        document.title = 'Login page';
    }, []);
    const handleSubmit = async () => {
        try {
            if (email.length <= 0 || password.length <= 0) {
                message.warning("Bạn phải điền hết các trường bắt buộc")
            } else {
                const payload = {
                    "email": email,
                    "password": password
                }
                const { data } = await axiosService("login", "POST", payload)
                const {token} = data
                localStorage.setItem("access_token",token)
                return navigate("/");
            }
        } catch (error) {
            message.error("Đăng nhập thất bại")
            console.log(error)
        }
    }
    return (
        <>
            <section className="h-100 gradient-form">
                <div className="container py-5 h-100">
                    <div className="row d-flex justify-content-center align-items-center h-100">
                        <div className="col-xl-10">
                            <div className="card rounded-3 text-black">
                                <div className="row g-0">
                                    <div className="col-lg-6">
                                        <div className="card-body p-md-5 mx-md-4">
                                            <div className="text-center">
                                                {/* <img src="/logo-login.png"  alt="logo" /> */}
                                                <h4 className="mt-1 mb-5 pb-1">We are The Team</h4>
                                            </div>
                                            <form onSubmit={() => { handleSubmit() }}>
                                                <p>Vui lòng đăng nhập</p>
                                                <div className="form-outline mb-4">
                                                    <input type="email" className="form-control" placeholder="Vui lòng nhập email"
                                                        onChange={onChangeEmail}
                                                    />
                                                </div>
                                                <div className="form-outline mb-4">
                                                    <input type="password" placeholder="Vui lòng nhập mật khẩu" className="form-control" onChange={onChangePassword} />
                                                </div>
                                                <div className="text-center pt-1 mb-5 pb-1">
                                                    <button className="btn btn-block fa-lg gradient-custom-2 mb-3 w-100 text-white" type="button"
                                                        onClick={handleSubmit}
                                                    >
                                                        Đăng nhập
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <div className="col-lg-6 d-flex align-items-center gradient-custom-2">
                                        <div className="text-white px-3 py-4 p-md-5 mx-md-4">
                                            <h4 className="mb-4">We are more than just a company</h4>
                                            <p className="small mb-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
                                                exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}