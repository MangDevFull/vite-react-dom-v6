import React, { useState } from 'react';
import { Layout, Menu, theme, Avatar, Dropdown, message } from 'antd';
const { Content, Sider, Header } = Layout;
import BreadcrumbComponent from './BreadCrumb';
import {
  PieChartOutlined,
  MailOutlined,
  UserOutlined,
  ArrowRightOutlined
} from '@ant-design/icons';
import './main.css';
import { useNavigate } from "react-router-dom";
import axiosService from "../../utils/axios.config";
export default function LayoutComponent({ children }) {
  let navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);
  function getItem(label, key, icon, children, type) {
    return {
      key,
      icon,
      children,
      label,
      type,
    };
  }
  const {
    token: { colorBgContainer },
  } = theme.useToken();
  const items = [
    getItem('Option 1', '1', <PieChartOutlined />),
    getItem('Navigation One', 'sub1', <MailOutlined />, [
      getItem('Option 5', '5'),
      getItem('Option 6', '6'),
      getItem('Option 7', '7'),
      getItem('Option 8', '8'),
    ]),
  ];
  const handleLogout = async () => {
    try {
      const { data, status } = await axiosService("logout", "post")
      if (data == "OK" && status === 200) {
        localStorage.removeItem("access_token")
        return navigate("/login")
      } else {
        message.error("Đăng nhập thất bại")
      }
    } catch (error) {
      console.error(error)
      message.error("Đăng xuất thất bại")
    }
  }
  const itemsDrop = [
    {
      key: '1',
      label: (
        <div className='d-flex' onClick={handleLogout}>
          <ArrowRightOutlined className="mt-1" />
          <span>
            Đăng xuất
          </span>
        </div>
      ),
    },
  ];
  return (
    <Layout
      style={{
        minHeight: '100vh',
      }}
    >
      <Sider collapsible collapsed={collapsed} onCollapse={(value) => setCollapsed(value)}>
        <img src='/logo.png' className='logo' />
        <Menu theme="dark" defaultSelectedKeys={['1']} mode="inline" items={items} />
      </Sider>
      <Layout className="site-layout">
        <Header
          style={{
            background: colorBgContainer,
          }}
          className="pt-3"
        >
          <div className='d-flex justify-content-end'>
            <Dropdown
              menu={{
                items: itemsDrop,
              }}
              placement="bottom"
              arrow
            >
              <Avatar size="large" icon={<UserOutlined />} />
            </Dropdown>
          </div>
        </Header>
        <Content className='m-2'>
          <BreadcrumbComponent />
          {children}
        </Content>
      </Layout>
    </Layout>
  );
}
