export default {
    ADMIN: 1
}