import 'antd/dist/reset.css';
import { createBrowserHistory } from 'history';
export const history = createBrowserHistory();
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Login from "./components/authen/Login";
import DashBoard from "./components/DashBoard";
import { AuthenticationMiddle } from "./middleware/authentication";
import Authorize from "./middleware/authorize";
import NotfoundPage from './components/results/404';
import 'bootstrap/dist/css/bootstrap.min.css';
export default function App() {
    return (

        <BrowserRouter>
            <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="*" element={<NotfoundPage />} />
                <Route element={<AuthenticationMiddle />}>
                    <Route path="/" element={<DashBoard />} />
                    <Route path="/dashboard" element={
                        <DashBoard />
                    } />
                </Route>
            </Routes>
        </BrowserRouter>
    );
}