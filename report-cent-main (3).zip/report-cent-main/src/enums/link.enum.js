export default{
    HOME_PAGE : "/",
    LOGIN_PAGE : "/login"
}