
import {
    HomeOutlined,
    MailOutlined,
} from '@ant-design/icons';
import React, { useState } from 'react';
import linkEnum from '../../enums/link.enum';
import { Layout, Menu } from 'antd';
const { Sider } = Layout;
import { useNavigate } from "react-router-dom";
export default function DesktopMenu() {
    let navigate = useNavigate();
    const [collapsed, setCollapsed] = useState(false);
    function getItem(label, key, icon, children, type) {
        return {
            key,
            icon,
            children,
            label,
            type,
        };
    }
    const items = [
        getItem('Trang chủ', linkEnum.HOME_PAGE, <HomeOutlined />),
        getItem('Navigation One', 'sub1', <MailOutlined />, [
            getItem('Option 5', '5'),
            getItem('Option 6', '6'),
            getItem('Option 7', '7'),
            getItem('Option 8', '8'),
        ]),
    ];
    const handleRedirect = (link) => {
        console.log("link", link)
        return navigate(link)
    }
    return (
        <Sider collapsible collapsed={collapsed} onCollapse={(value) => setCollapsed(value)} className="mobile">
            {collapsed ? <div className='logo'></div> : <img style={{ cursor: "pointer" }} src='/logo.png' className='logo' onClick={() => { handleRedirect(linkEnum.HOME_PAGE) }} />}
            <Menu theme="dark" defaultSelectedKeys={[linkEnum.HOME_PAGE]} mode="inline" items={items} onSelect={(e) => {
                const { key } = e
                handleRedirect(key)
            }} />
        </Sider>
    )
}